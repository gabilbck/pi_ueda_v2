<?php 
    include "../../include/MySql.php";
    include "../../include/functions.php";
    session_start();
?>
<head>
    <title>Alterar informações do Erro</title>
</head>
<?php require("../../template/header3.php");?>
    <main>

    </main>
<?php require("../../template/footer3.php");?>