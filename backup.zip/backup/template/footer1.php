<footer>
    <center>
        <div class="margem-lados">
            <div>
                PROJETO INTEGRADOR UEDA - 2022
            </div>
            <hr class="hr-footer">
            <table>
                <tr>
                    <td>
                        <table>
                            <tr>
                                <td><a href="index.php"><img src="images/logo.png" alt="UEDA" title="Logo UEDA" width="80"></a></td>
                            </tr>
                        </table>
                    </td>
                    <td>
                        <table>
                            <tr>
                                <td colspan="2" class="redes"><a>Redes Sociais:</a></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="https://www.instagram.com/projeto_ueda/">
                                        <img src="images/insta.png" alt="Instagram">
                                    </a>
                                </td>
                                <td class="redes">
                                    <a class="f-menor" href="https://www.instagram.com/projeto_ueda/">Instagram</a>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <a href="#">
                                        <img src="images/twitter.png" alt="Twitter">
                                    </a>
                                </td>
                                <td class="redes">
                                    <a class="f-menor" href="https://twitter.com/UEDA_PI">Twitter</a>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
            <div class="margem-footer1"></div>
            <a class="reportar" href="bug.php">Encontrou algum erro? Reporte agora!</a>
            <div class="margem-footer2"></div>
        </div>
    </center>
</footer>
</body>
</html>