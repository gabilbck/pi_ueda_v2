<?php
    /* Visualização do artigo selecionado */

    include "../include/MySql.php";
    include "../include/functions.php";
    session_start();
?>