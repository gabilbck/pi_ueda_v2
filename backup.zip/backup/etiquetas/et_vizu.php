<?php
    /* Artigos relaionados a etiqueta selecionada pelo usuário */

    // include "../include/MySql.php";
    // include "../include/functions.php";
?>